using System.Collections.Generic;

namespace VsCodeApiApp.Services
{
    public class VsCodeApiService : IVsCodeApiService
    {     
        public string Greeting()
        {
            // TestClassLib.SampleLib abc=new TestClassLib.SampleLib();
            GreetClassLib.SampleLib libSample=new GreetClassLib.SampleLib();
            return libSample.Greeting();
        }

    }
}