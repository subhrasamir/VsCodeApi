using System.Collections.Generic;

namespace VsCodeApiApp.Services
{
    public interface IVsCodeApiService
    {     
        string Greeting();
    }
}