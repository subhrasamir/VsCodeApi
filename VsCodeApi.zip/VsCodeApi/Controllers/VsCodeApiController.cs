using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VsCodeApiApp.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace VsCodeApiApp.Controllers
{
    [ApiController]
    [Route("api/VsCodeApi/Greet")]
    public class VsCodeApiController : ControllerBase
    {
        private IVsCodeApiService _vsCodeApiService; 

        public VsCodeApiController(IVsCodeApiService vsCodeApiService)
        {
            _vsCodeApiService = vsCodeApiService;
        }

       
        [HttpGet]
        public string Greeting()
        {
           return _vsCodeApiService.Greeting();
       
        }
    }
}
